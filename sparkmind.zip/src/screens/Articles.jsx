import {
  FlatList,
  Image,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { COLORS } from "../consts/COLORS";
import { supabase } from "../utils/supabase";
import { useNavigation } from "@react-navigation/native";

export default function Articles() {
  const [articles, setArticles] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("depression");
  const navigation = useNavigation();
  const categories = ["depression", "motivational"];
  async function fetchArticles() {
    const { data, error } = await supabase.from("Articles").select("*");
    console.log(data);
    setArticles(data);
  }
  useEffect(() => {
    fetchArticles();
  }, []);
  return (
    <ScrollView style={styles.wrapper}>
      <FlatList
        data={categories}
        horizontal
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => {
              setSelectedCategory(item);
            }}

            style={{
              padding: 10,
              borderRadius: 10,
              backgroundColor: selectedCategory === item ? COLORS.primary : "white",
              margin: 10,
            }}
          >
            <Text style={{ 
              color: selectedCategory === item ? "white" : "black",
              }}>#{item}</Text>
          </TouchableOpacity>
        )}
      />
      <StatusBar backgroundColor={COLORS.primary} />
      {articles
        .filter((article) => article.category === selectedCategory)
        .map((article) => {
          return (
            <TouchableOpacity
              key={article.id}
              onPress={() => {
                navigation.navigate("Article", { article });
              }}
              style={{
                display: "flex",
                gap: 5,
                backgroundColor: "white",
                padding: 10,
                borderRadius: 10,
              }}
            >
              <Image source={{ uri: article.url }} style={{ height: 200 }} />
              <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
                {article.title}
              </Text>

              <Text>#{article.category}</Text>
            </TouchableOpacity>
          );
        })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
  },
});
