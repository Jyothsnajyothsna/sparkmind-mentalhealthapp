import { ScrollView, StyleSheet, Text, View } from "react-native";
import React from "react";

export default function Article(props) {
  console.log(props.route.params);
  return (
    <ScrollView style={styles.wrapper}>
      <Text style={styles.title}>{props.route.params.article.title}</Text>
      <Text style={styles.body}>{props.route.params.article.content}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: {
    fontFamily: "Quicksand_700Bold",
    fontSize: 24,
  },
  body:{
    fontFamily: "Quicksand_500Medium",
    fontSize: 16,
    paddingBottom: 20,
  },
  wrapper: {
    padding: 10,
  },
});
