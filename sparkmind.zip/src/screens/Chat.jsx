import {
  View,
  Text,
  StatusBar,
  StyleSheet,
  TextInput,
  ScrollView,
} from "react-native";
import React, { useState } from "react";
import { COLORS } from "../consts/COLORS";
import { supabase } from "../utils/supabase";
import Button from "../components/Button";

export default function Chat() {
  const [query, setQuery] = useState("");
  const [chats, setChats] = useState([]);
  async function brew() {
    const { data, error } = await supabase.functions.invoke("openai", {
      body: { query: "I am feeling sad" },
    });
    console.log(data, error);
  }
  const handleClick = async () => {
    const { data, error } = await supabase.functions.invoke("openai", {
      body: { query },
    });
    setChats([
      ...chats,
      { author: "user", text: query },
      { author: "bot", text: data.choices[0].text.trim() },
    ]);
    console.log(chats);
    setQuery("");
  };
  return (
    <ScrollView style={styles.wrapper}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.primary} />
      {chats.map((chat) => (
        <View
          style={{
            display: "flex",
            flexDirection: "row",
          }}
        >
          <View
            style={{
              padding: 10,
              borderRadius: 10,
              margin: 10,
              backgroundColor:
                chat.author === "user" ? COLORS.primary : COLORS.secondary,
            }}
          >
            <Text>{chat.text}</Text>
          </View>
        </View>
      ))}
      <TextInput
        style={styles.textInput}
        value={query}
        placeholder="Type your message here"
        onChangeText={(text) => setQuery(text)}
      />

      <Button onPress={() => handleClick()} label={"Send"} />
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
  },
  textInput: {
    borderRadius: 5,
    padding: 10,
    backgroundColor: "white",
    marginBottom: 10,
  },
});
