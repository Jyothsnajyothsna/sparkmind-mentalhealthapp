import {
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { COLORS } from "../consts/COLORS";
import { supabase } from "../utils/supabase";
import * as Linking from "expo-linking";
const categories = ["meditation", "yoga", "exercise"];
export default function Yogas() {
  const [selectedCategory, setSelectedCategory] = useState("meditation");
  const [yogas, setYogas] = useState([]);
  async function fetchYogas() {
    const { data, error } = await supabase.from("Yogas").select("*");
    setYogas(data);
  }
  useEffect(() => {
    fetchYogas();
  }, []);
  return (
    <ScrollView style={styles.wrapper}>
      <StatusBar backgroundColor={COLORS.primary} />
      <FlatList
        data={categories}
        horizontal
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => {
              setSelectedCategory(item);
            }}
            style={{
              padding: 10,
              borderRadius: 10,
              backgroundColor:
                selectedCategory === item ? COLORS.primary : "white",
              margin: 10,
            }}
          >
            <Text
              style={{
                color: selectedCategory === item ? "white" : "black",
              }}
            >
              #{item}
            </Text>
          </TouchableOpacity>
        )}
      />
      {yogas
        .filter((yoga) => yoga.category === selectedCategory)
        .map((yoga) => {
          return (
            <Pressable
              style={{
                display: "flex",
                flexDirection: "row",
                gap: 10,
                alignItems: "center",
                marginBottom: 10,
              }}
            >
              <Image
                style={{ width: 100, height: 100, borderRadius: 500 ,paddingLeft:10,paddingRight:10}}
                source={{ uri: yoga.url }}
              />
              <View>
                <Text style={{paddingBottom:5}}>{yoga.title}</Text>
                <Text style={styles.wrapper}>Description: {yoga.description}</Text>
               <Pressable 
                onPress={() => {
                  Linking.openURL(yoga.video_url);
                  }}>
                    <Text style={{paddingTop:5,color:COLORS.blue}}>
                      View Video Tutorial
                    </Text>
                </Pressable> 
              </View>
            </Pressable>
          );
        })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    paddingRight: 15,
  },
});
