import { View, Text, ScrollView, Pressable } from "react-native";
import React, { useEffect, useState } from "react";
import { supabase } from "../utils/supabase";
import { StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as Linking from "expo-linking";

export default function Musics() {
  const [musics, setMusics] = useState();
  async function fetchmusics() {
    const { data, error } = await supabase.from("Music").select("*");
    setMusics(data);
  }
  const onMusicPress = (url) => {
    Linking.openURL(url);
  };
  useEffect(() => {
    fetchmusics();
  }, []);
  return (
    <ScrollView style={styles.wrapper}>
      {musics &&
        musics.map((music) => (
          <Pressable
            onPress={() => onMusicPress(music.url)}
            key={music.id}
            style={styles.music}
          >
            <View
              style={{
                borderWidth: 1,
                width: 40,
                height: 40,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: 50,
                borderColor: "grey",
              }}
            >
              <Ionicons name="musical-notes" size={24} color="black" />
            </View>
            <Text style={{ fontFamily: "Quicksand_500Medium" }}>
              {music.title}
            </Text>
          </Pressable>
        ))}
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
  },
  music: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: "grey",
  },
});
