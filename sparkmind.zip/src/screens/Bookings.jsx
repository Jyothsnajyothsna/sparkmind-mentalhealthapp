import { View, Text, StyleSheet, ScrollView } from "react-native";
import React, { useEffect, useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabase";

export default function Bookings() {
  const { session } = useAuth();
  const [bookings, setBookings] = useState([]);
  async function fetchBookings() {
    const { data, error } = await supabase
      .from("Bookings")
      .select("*")
      .eq("user", session.user.id);
    console.log(data, error);
    setBookings(data);
  }
  useEffect(() => {
    fetchBookings();
  }, [session]);
  return (
    <ScrollView style={styles.wrapper}>
      {bookings.map((booking) => {
        return (
          <View style={styles.booking} key={booking.id}>
            <Text>Booking with {booking.therapist}</Text>
            <Text>Time {booking.date}</Text>
          </View>
        );
      })}
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
  },
  booking: {
    backgroundColor: "white",
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
  },
});
