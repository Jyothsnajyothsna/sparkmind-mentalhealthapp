import {
  View,
  Text,
  TextInput,
  Pressable,
  ToastAndroid,
  ScrollView,
} from "react-native";
import React, { useEffect, useState } from "react";
import { StyleSheet } from "react-native";
import { useAuth } from "../contexts/AuthContext";
import Button from "../components/Button";
import { supabase } from "../utils/supabase";
import { COLORS } from "../consts/COLORS";


export default function Profile() {
  const { session } = useAuth();
  const [user, setUser] = useState();
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [blood_group, setBlood_group] = useState("");
  const [mental_concerns, setMental_concerns] = useState("");
  const [relationship_status, setRelationship_status] = useState("");
  const [mobile_number, setMobile_number] = useState("");
  const [profile, setProfile] = useState({
    user: session.user.id,
    name: "",
    age: "",
    blood_group: "",
    mental_concerns: "",
    gender: "",
    relationship_status: "",
    mobile_number: "",
  });
  async function logout() {
    await supabase.auth.signOut();
  }
  async function fetchProfile() {
    const { data, error } = await supabase
      .from("Users")
      .select("*")
      .eq("user", session.user.id);
    const user = data[0];
    if (user) setProfile(user);
    console.log(user);
  }
  useEffect(() => {
    fetchProfile();
  }, []);
  async function handleUpdate() {
    setUser(session.user.id);
    const { data, error } = await supabase.from("Users").upsert(
      {
        name: profile.name,
        user: session.user.id,
        age: profile.age,
        blood_group: profile.blood_group,
        gender: profile.gender,
        mental_concerns: profile.mental_concerns,
        relationship_status: profile.relationship_status,
        mobile_number: profile.mobile_number,
      },
      {onConflict: "user"}
    );


    if (data) ToastAndroid.show("Updated Successfully", ToastAndroid.SHORT);
    fetchProfile();
  }

  return (
    <ScrollView style={styles.wrapper}>
      <View style={{ display: "flex", gap: 10 }}>
        <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Name
        </Text>
        <TextInput
          onChangeText={(text) => {
            setProfile({ ...profile, name: text });
          }}
          placeholder="Enter Your Name"
          value={profile.name ? profile.name : ""}
          style={styles.textInput}
        />
       
        <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Mobile Number
        </Text>
        <TextInput
          onChangeText={(text) => {
            setProfile({ ...profile, mobile_number: text});  
          }}
          placeholder="Enter Your Mobile Number"
          value={profile.mobile_number ? profile.mobile_number : ""}
          style={styles.textInput}
        />
        <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Age
        </Text>
        <TextInput
        keyboardType="numeric"
          onChangeText={(text) => {
            setProfile({ ...profile, age: text });  
          }}
          placeholder="Enter Your age"
          value={profile.age ? profile.age : ""}
          style={styles.textInput}
        />
        <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Blood Group
        </Text>
        <TextInput
          onChangeText={(text) => {
            setProfile({ ...profile, blood_group: text });
          }}
          placeholder="Enter Your Blood Group"
          value={profile.blood_group ? profile.blood_group : ""}
          style={styles.textInput}
        />
        {/* <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Gender
        </Text>
        <TextInput
          onChangeText={(text) => {
            placeholder="M or F",
          }
            /> */}
        <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Mental Concerns
        </Text>
        <TextInput
          onChangeText={(text) => {
            setProfile({ ...profile, mental_concerns: text });
          }}
          placeholder="Enter Your Mental Concerns"
          value={profile.mental_concerns ? profile.mental_concerns : ""}
          style={styles.textInput}
        />
        
        <Text style={{ fontFamily: "Quicksand_500Medium", fontSize: 18 }}>
          Relationship Status
        </Text>
        <TextInput
          onChangeText={(text) => {
            setProfile({ ...profile, relationship_status: text });
          }}
          placeholder="Enter Your Relationship Status"
          value={profile.relationship_status ? profile.relationship_status : ""}
          style={styles.textInput}
        />
        
      </View>
      <Button label={"Update Profile"} onPress={()=>{
          handleUpdate();
          // navigator.navigate("Profile")
      }
        
        } />
      <Pressable
        onPress={() => {
          logout();
        }}
        style={{
          backgroundColor: COLORS.primary,
          padding: 10,
          borderRadius: 5,
        }}
      >

        <Text>Logout</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
    display: "flex",
    gap: 10,
  },
  textInput: {
    borderRadius: 5,
    padding: 10,
    backgroundColor: "white",
    fontFamily: "Quicksand_400Regular",
  },
});
