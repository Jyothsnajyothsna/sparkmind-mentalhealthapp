import { View, StyleSheet, TextInput, Text, StatusBar,Image } from "react-native";
import React, { useState } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import Button from "../../components/Button";
import { COLORS } from "../../consts/COLORS";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../../contexts/AuthContext";

export default function Login() {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const navigation = useNavigation();
  const { login } = useAuth();
  
  
  return (
    <SafeAreaProvider style={styles.wrapper}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <Image
      source={{uri:"https://images.theconversation.com/files/454716/original/file-20220328-15-1rfv76b.jpg?ixlib=rb-1.1.0&rect=16%2C0%2C3578%2C1880&q=45&auto=format&w=926&fit=clip"}}
      />
      <View style={{ display: "flex", gap: 10 }}>
        <Text style={{ fontFamily: "Quicksand_400Regular", fontSize: 18 }}>
          Email
        </Text>
        <TextInput
          onChangeText={(text) =>
            setCredentials({ ...credentials, email: text })
          }
          style={styles.textInput}
        />
      </View>
      <View style={{ display: "flex", gap: 10 }}>
        <Text style={{ fontFamily: "Quicksand_400Regular", fontSize: 18 }}>
          Password
        </Text>
        <TextInput
          onChangeText={(text) =>
            setCredentials({ ...credentials, password: text })
          }
          secureTextEntry={true}
          style={styles.textInput}
        />
      </View>
      <Button
        onPress={() => login(credentials.email, credentials.password)}
        label={"Login"}
      />
      <View>
        <Text onPress={() => navigation.navigate("Register")}>
          Don't have an account? Register
        </Text>
      </View>
    </SafeAreaProvider>
  );
}
const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
    display: "flex",
    gap: 20,
  },
  textInput: {
    borderRadius: 5,
    padding: 10,
    backgroundColor: "white",
  },
});
