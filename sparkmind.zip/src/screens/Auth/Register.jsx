import { View, StyleSheet, TextInput, Text, StatusBar } from "react-native";
import React, { useState } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import Button from "../../components/Button";
import { COLORS } from "../../consts/COLORS";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../../contexts/AuthContext";

export default function Register() {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const { register } = useAuth();
  const navigation = useNavigation();
  return (
    <SafeAreaProvider style={styles.wrapper}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <View style={{ display: "flex", gap: 10 }}>
        <Text style={{ fontFamily: "Quicksand_400Regular", fontSize: 18 }}>
          Email
        </Text>
        <TextInput
          onChangeText={(text) =>
            setCredentials({ ...credentials, email: text })
          }
          style={styles.textInput}
        />
      </View>
      <View style={{ display: "flex", gap: 10 }}>
        <Text style={{ fontFamily: "Quicksand_400Regular", fontSize: 18 }}>
          Password
        </Text>
        <TextInput
          secureTextEntry={true}
          onChangeText={(text) =>
            setCredentials({ ...credentials, password: text })
          }
          style={styles.textInput}
        />
      </View>
      <Button
        label={"Register"}
        onPress={() => register(credentials.email, credentials.password)}
      />
      <View>
        <Text onPress={() => navigation.navigate("Login")}>
          Already have an account? Login
        </Text>
      </View>
    </SafeAreaProvider>
  );
}
const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
    display: "flex",
    gap: 20,
  },
  textInput: {
    borderRadius: 5,
    padding: 10,
    backgroundColor: "white",
    fontFamily: "Quicksand_400Regular",
  },
});
