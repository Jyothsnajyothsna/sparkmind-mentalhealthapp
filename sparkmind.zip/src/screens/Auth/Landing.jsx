import React from "react";
import { StyleSheet, Image, Dimensions, Text, View } from "react-native";
import AntDesign from "@expo/vector-icons/AntDesign";
import Swiper from "react-native-swiper";
import { useNavigation } from "@react-navigation/native";
import Button from "../../components/Button";

const w = Dimensions.get("window").width;
const h = Dimensions.get("window").height;

const styles = StyleSheet.create({
  slide: {
    flex: 1,
    paddingTop: 80,
    marginHorizontal: 30,
  },
  img: {
    alignSelf: "center",
    borderTopRightRadius: 80,
    borderBottomLeftRadius: 80,
    height: h * 0.5,
    width: w * 0.9,
  },
  title: {
    marginTop: 60,
    marginHorizontal: 10,
    fontSize: 32,
  },
  text: {
    color: "#767676",
    marginTop: 20,
    fontSize: 16,
    lineHeight: 25,
    marginLeft: 10,
  },
});

const Landing = () => {
    const navigation = useNavigation();
  return (
    <>
      <Swiper
        buttonWrapperStyle={{
          backgroundColor: "transparent",
          flexDirection: "row",
          position: "absolute",
          bottom: 0,
          left: 0,
          flex: 1,
          paddingHorizontal: 30,
          paddingVertical: 20,
          justifyContent: "flex-end",
          alignItems: "flex-end",
        }}
        style={styles.wrapper}  
        
        
        nextButton={
          <View
            style={{
              height: 60,
              borderRadius: 30,
              alignItems: "center",
              justifyContent: "center",
              width: 60,
              backgroundColor: "#000000",
            }}
          >
            <AntDesign name="arrowright" size={22} color="#FFF" />
          </View>
        }
        prevButton={
          <View
            style={{
              height: 60,
              borderRadius: 30,
              alignItems: "center",
              justifyContent: "center",
              width: 60,
              backgroundColor: "#000000",
              marginHorizontal: 20,
            }}
          >
            <AntDesign name="arrowleft" size={22} color="#FFF" />
          </View>
        }
      >
        <View style={styles.slide}>
          <Image
            source={{ uri: "https://cdn.pixabay.com/photo/2022/07/15/18/27/mental-health-7323725_640.png" }}
            style={styles.img}
          />
          <Text style={styles.title}>Chatbot</Text>
          <Text style={styles.text}>
          Engage in meaningful conversations anytime, anywhere with our chat bot feature, offering instant support and a 
          non-judgmental space to express your thoughts and emotions.
          </Text>
        </View>
        <View style={styles.slide}>
          <Image
            source={{ uri: "https://img.freepik.com/free-vector/hand-drawn-world-mental-health-day_52683-44659.jpg" }}
            style={styles.img}
          />
          <Text style={styles.title}>Therapist</Text>
          <Text style={styles.text}>
          Discover a curated list of qualified therapists and easily book appointments, connecting you with the right 
          professional who can provide personalized guidance and support.
          </Text>
        </View>

        <View style={styles.slide}>
          <Image
            source={{ uri: "https://images.theconversation.com/files/454716/original/file-20220328-15-1rfv76b.jpg?ixlib=rb-1.1.0&rect=16%2C0%2C3578%2C1880&q=45&auto=format&w=926&fit=clip" }}
            style={styles.img}
          />
          <Text style={styles.title}>Articles</Text>
          <Text style={styles.text}>
          Access a dedicated page filled with informative articles on various mental health topics, 
          empowering you with knowledge and insights to better understand and manage your mental well-being.
          </Text>
        </View>
        <View style={styles.slide}>
          <Image
            source={{ uri: "https://www.creativefabrica.com/wp-content/uploads/2023/02/11/Mental-Health-Anxiety-Floral-PNG-Graphics-60792456-1.jpg" }}
            style={styles.img}
          />
          <Text style={styles.title}>Yoga</Text>
          <Text style={styles.text}>
          Nurture your mind and body through our yoga and mindfulness section, providing step-by-step instructions and 
          resources to help you incorporate self-care practices into your daily routine for enhanced mental health.
          </Text>
        </View>
      </Swiper>
      <View
        style={{
          position: "relative",
          bottom: 20,
          paddingHorizontal: 20,
          marginTop: 20,
        }}
      >
        <Button
          label={"Get Started"}
          onPress={() => navigation.navigate("Login")}
        />
      </View>
    </>
  );
};

export default Landing;