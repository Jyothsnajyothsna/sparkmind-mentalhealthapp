import {
  Image,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import React, { useEffect, useState } from "react";
import { COLORS } from "../consts/COLORS";
import { supabase } from "../utils/supabase";
import { Ionicons } from "@expo/vector-icons";
import Button from "../components/Button";
import { useAuth } from "../contexts/AuthContext";
import { useNavigation } from "@react-navigation/native";
export default function Therapists() {
  const navigation = useNavigation();
  const [therapists, setTherapists] = useState([]);
  const [therapist, setTherapist] = useState([]);
  const { session } = useAuth();
  const [date, setDate] = useState();
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    setDate(date);
    hideDatePicker();
    book();
  };
  async function book() {
    console.log(date)
    const { data, error } = await supabase.from("Bookings").insert({
      therapist: therapist,
      user: session.user.id,
      date: date,
    });
    navigation.navigate("Bookings");
  }

  async function fetchTherapists() {
    const { data, error } = await supabase.from("Therapist").select("*");
    console.log(data);
    setTherapists(data);
  }
  useEffect(() => {
    fetchTherapists();
  }, []);
  return (
    <ScrollView style={styles.wrapper}>
      <StatusBar backgroundColor={COLORS.primary} />
      <Button
        label={"Show My Bookings"}
        onPress={() => {
          navigation.navigate("Bookings");
        }}
      />
      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="datetime"
        minimumDate={new Date()}
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />

      {therapists.map((therapist) => {
        return (
          <View
            key={therapist.id}
            style={{
              backgroundColor: "white",
              padding: 10,
              borderRadius: 10,
              display: "flex",
              gap: 5,
              marginBottom: 10,
            }}
          >
            <View style={styles.info}>
              <Ionicons name="person-circle-sharp" size={20} />
              <Text>
                Name : {therapist.name} - {therapist.specialization}
              </Text>
            </View>
            <View style={styles.info}>
              <Ionicons name="cash-outline" size={20} />
              <Text>Fee : {therapist.fee}</Text>
            </View>
            <View style={styles.info}>
              <Ionicons name="time-outline" size={20} />
              <Text>Timings : {therapist.timing}</Text>
            </View>
            <View style={styles.info}>
              <Ionicons name="phone-portrait-outline" size={20} />
              <Text>Mobile : {therapist.mobile}</Text>
            </View>
            <Text>About Therapist : {therapist.about}</Text>
            <Button
              onPress={() => {
                setTherapist(therapist.name);
                setDatePickerVisibility(true);
              }}
              label={"Book Appointment"}
            />
          </View>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: 10,
  },
  info: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
});
