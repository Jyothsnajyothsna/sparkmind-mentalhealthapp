import { View, Text } from "react-native";
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import TabStack from "./TabStack";
import Article from "../screens/Article";
import { COLORS } from "../consts/COLORS";
import Bookings from "../screens/Bookings";
const Stack = createNativeStackNavigator();
export default function AppStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="TabStack"
        options={{ headerShown: false }}
        component={TabStack}
      />
      <Stack.Screen
        name="Article"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
        }}
        component={Article}
      />
      <Stack.Screen
        name="Bookings"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
        }}
        component={Bookings}
      />
    </Stack.Navigator>
  );
}
