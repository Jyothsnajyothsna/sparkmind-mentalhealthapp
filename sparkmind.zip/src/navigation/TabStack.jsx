import { View, Text } from "react-native";
import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Home from "../screens/Chat";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import Yogas from "../screens/Yogas";
import Articles from "../screens/Articles";
import Therapists from "../screens/Therapists";
import { COLORS } from "../consts/COLORS";
import Profile from "../screens/Profile";
import Musics from "../screens/Musics";
const Tab = createBottomTabNavigator();
export default function TabStack() {
  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Chat"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
          tabBarStyle: {
            backgroundColor: COLORS.primary,
            paddingVertical: 10,
            height: 60,
          },
          tabBarLabelStyle: {
            fontFamily: "Quicksand_500Medium",
            color: "black",
          },
          tabBarIcon: ({ focused }) => (
            <MaterialCommunityIcons
              name="chat"
              size={24}
              color={focused ? "black" : COLORS.background}
            />
          ),
        }}
        component={Home}
      />
      <Tab.Screen
        name="Therapists"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
          tabBarStyle: {
            backgroundColor: COLORS.primary,
            paddingVertical: 10,
            height: 60,
          },
          tabBarLabelStyle: {
            fontFamily: "Quicksand_500Medium",
            color: "black",
          },
          headerTitleStyle: {
            fontFamily: "Quicksand_500Medium",
          },
          tabBarIcon: ({ focused }) => (
            <MaterialCommunityIcons
              name="heart-circle"
              size={24}
              color={focused ? "black" : COLORS.background}
            />
          ),
        }}
        component={Therapists}
      />
      <Tab.Screen
        name="Musics"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
          tabBarStyle: {
            backgroundColor: COLORS.primary,
            paddingVertical: 10,
            height: 60,
          },
          tabBarLabelStyle: {
            fontFamily: "Quicksand_500Medium",
            color: "black",
          },
          tabBarIcon: ({ focused }) => (
            <MaterialCommunityIcons
              name="music-circle"
              size={24}
              color={focused ? "black" : COLORS.background}
            />
          ),
        }}
        component={Musics}
      />
      <Tab.Screen
        name="Articles"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
          tabBarStyle: {
            backgroundColor: COLORS.primary,
            paddingVertical: 10,
            height: 60,
          },
          tabBarLabelStyle: {
            fontFamily: "Quicksand_500Medium",
            color: "black",
          },
          tabBarIcon: ({ focused }) => (
            <MaterialCommunityIcons
              name="newspaper"
              size={24}
              color={focused ? "black" : COLORS.background}
            />
          ),
        }}
        component={Articles}
      />
      <Tab.Screen
        name="Yogas"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
          tabBarStyle: {
            backgroundColor: COLORS.primary,
            paddingVertical: 10,
            height: 60,
          },
          tabBarLabelStyle: {
            fontFamily: "Quicksand_500Medium",
            color: "black",
          },
          tabBarIcon: ({ focused }) => (
            <MaterialCommunityIcons
              name="yoga"
              size={24}
              color={focused ? "black" : COLORS.background}
            />
          ),
        }}
        component={Yogas}
      />
      <Tab.Screen
        name="Profile"
        options={{
          headerStyle: {
            backgroundColor: COLORS.primary,
          },
          tabBarStyle: {
            backgroundColor: COLORS.primary,
            paddingVertical: 10,
            height: 60,
          },
          tabBarLabelStyle: {
            fontFamily: "Quicksand_500Medium",
            color: "black",
          },
          tabBarIcon: ({ focused }) => (
            <MaterialCommunityIcons
              name="account-circle"
              size={24}
              color={focused ? "black" : COLORS.background}
            />
          ),
        }}
        component={Profile}
      />
      
      
    </Tab.Navigator>
  );
}
