import { View, Text } from "react-native";
import React from "react";
import Login from "../screens/Auth/Login";
import Register from "../screens/Auth/Register";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Landing from "../screens/Auth/Landing";
const Stack = createNativeStackNavigator();

export default function AuthStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Landing"
        options={{
          headerShown: false,
        }}
        component={Landing}
      />
      <Stack.Screen
        name="Login"
        options={{
          headerShown: false,
        }}
        component={Login}
      />
      <Stack.Screen
        name="Register"
        options={{
          headerShown: false,
        }}
        component={Register}
      />
    </Stack.Navigator>
  );
}
