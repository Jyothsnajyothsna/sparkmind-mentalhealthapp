export const COLORS = {
  primary: "#a482d3",
  secondary: "#eee8f7",
  background: "#eee8f7",
  blue: "#3f51b5",
};
