import { StyleSheet, Text, Pressable } from "react-native";
import React from "react";
import { COLORS } from "../consts/COLORS";

export default function Button({ label, onPress, disabled }) {
  return (
    <Pressable style={styles.wrapper} onPress={onPress} disabled={disabled}>
      <Text style={styles.buttonText}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: COLORS.primary,
    padding: 10,
    borderRadius: 5,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    fontFamily: "Quicksand_700Bold",
    fontSize: 18,
  },
});
