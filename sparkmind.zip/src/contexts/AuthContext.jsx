import React, { useContext, useState, useEffect } from "react";
import { supabase } from "../utils/supabase";
import { ToastAndroid } from "react-native";
const AuthContext = React.createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });
  }, []);
  async function login(email, password) {
    console.log(email,password)
    const { error } = await supabase.auth.signInWithPassword({
      email: email,
      password: password,
    });
    console.log(error)
    if(error) ToastAndroid.show("Invalid Credntials", ToastAndroid.SHORT)
  }
  async function register(email, password) {
    const { error } = await supabase.auth.signUp({
      email: email,
      password: password,
    });
  }
  async function logout() {
    await supabase.auth.signOut();
  }
  const value = {
    session,
    register,
    login,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
