import React, { useContext, useState, useEffect } from "react";
import { supabase } from "../utils/supabase";
import { useAuth } from "./AuthContext";
const DataContext = React.createContext();

export function useData() {
  return useContext(DataContext);
}

export function DataProvider({ children }) {
  const [user, setUser] = useState(null);
  const { session } = useAuth();
  async function getUser() {
    const { data, error } = await supabase
      .from("Users")
      .eq("id", session.user.id)
      .single();
    setUser(data);
  }
  useEffect(() => {
    if (session) {
      getUser();
    }
  }, [session]);

  const value = { user };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}
