import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { ChatCompletion } from "https://deno.land/x/openai/mod.ts";

serve(async (req) => {
  const { query } = await req.json();

  const completionConfig: ChatCompletion = {
    model: "text-davinci-003",
    prompt:
      "You are a mental support bot, you need to give a solution to anything the user says, do not complete the users sentence, just anbalyze the problem and give a  solution, now answer to this sentence said by a user" +
      query,
    max_tokens: 256,
    temperature: 0,
    stream: false,
  };

  return fetch("https://api.openai.com/v1/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(completionConfig),
  });
});
