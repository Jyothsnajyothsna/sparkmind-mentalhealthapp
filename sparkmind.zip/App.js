import "react-native-url-polyfill/auto";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Login from "./src/screens/Auth/Login";
import {
  useFonts,
  Quicksand_300Light,
  Quicksand_400Regular,
  Quicksand_500Medium,
  Quicksand_600SemiBold,
  Quicksand_700Bold,
} from "@expo-google-fonts/quicksand";
import { COLORS } from "./src/consts/COLORS";
import Register from "./src/screens/Auth/Register";
import TabStack from "./src/navigation/TabStack";
import AuthStack from "./src/navigation/AuthStack";
import { useEffect, useState } from "react";
import { supabase } from "./src/utils/supabase";
import AppStack from "./src/navigation/AppStack";
import { AuthProvider } from "./src/contexts/AuthContext";

const Stack = createNativeStackNavigator();
const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: COLORS.background,
  },
};
export default function App() {
  let [fontsLoaded] = useFonts({
    Quicksand_300Light,
    Quicksand_400Regular,
    Quicksand_500Medium,
    Quicksand_600SemiBold,
    Quicksand_700Bold,
  });
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });
  }, []);
  if (!fontsLoaded) return null;
  return (
    <NavigationContainer theme={MyTheme}>
      <AuthProvider>{session ? <AppStack /> : <AuthStack />}</AuthProvider>
    </NavigationContainer>
  );
}
